
function love.conf(t)

	t.screen.width = 800
	t.screen.height = 600


end
